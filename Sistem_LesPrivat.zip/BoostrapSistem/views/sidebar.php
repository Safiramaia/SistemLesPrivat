<div id="layoutSidenav">
  <div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-light bg-dark" id="sidenavAccordion">
      <div class="sb-sidenav-menu">
        <div class="nav">
          <div class="sb-sidenav-menu-heading" style="color: white;">ADMIN</div>
          <a class="nav-link" href="dashboard_admin.php"style="color: white;">
            <div class="sb-nav-link-icon"><i class="fas fa-house"></i></div>
            Dashboard
          </a>
          <a class="nav-link" href="tampil_siswa.php" style="color: white;">
            <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
            Data Siswa
          </a>
          <a class="nav-link" href="tampil_pengajar.php" style="color: white;">
            <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
            Data Pengajar
          </a>
          <a class="nav-link" href="tampil_mapel.php"style="color: white;">
            <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
            Data Mata Pelajaran
          </a>
          <a class="nav-link" href="tampil_jadwal.php" style="color: white;">
            <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
            Data Jadwal Les
          </a>
          <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#pagesCollapseAuth" aria-expanded="false" aria-controls="pagesCollapseAuth" style="color: white;">
            <div class="sb-nav-link-icon"><i class=" fas fa-user-check"></i></div>
              Kehadiran
              <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
          </a>
              <div class="collapse" id="pagesCollapseAuth" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordionPages" style="color: white;">
                <nav class="sb-sidenav-menu-nested nav">
                  <a class="nav-link" href="tampil_kehadiran.php" style="color: white;">Kehadiran Siswa</a>
                  <a class="nav-link" href="tampil_kehadiran_pengajar.php" style="color: white;">Kehadiran Pengajar</a>
                </nav>
              </div>
          </a>
            <a class="nav-link" href="tampil_pembayaran.php" style="color: white;">
             <div class="sb-nav-link-icon"><i class="fas fa-money-bill-wave"></i></div>
              Data Pembayaran
            </a>
      </div>
    </nav>
  </div>
</div>
